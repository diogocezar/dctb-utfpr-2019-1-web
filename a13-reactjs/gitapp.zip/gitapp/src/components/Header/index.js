import React from "react";
import "./styles.css";

const Header = () => <header id="main-header">Git App</header>;

export default Header;
